package com.example.bixbywakefix;

import android.content.Context;
import android.content.pm.PackageManager;
import android.media.AudioManager;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * Narrow hook: when ApWakeupService.isRecognitionAllowed() returns false,
 * flip it to true ONLY if Bixby is enabled and no call/communication is active.
 */
public class MainHook implements IXposedHookLoadPackage {

    private static final String TAG = "[BixbyWakeFix] ";
    private static final String TARGET_PKG = "com.samsung.android.bixby.wakeup";
    private static final String TARGET_CLASS =
            "com.samsung.android.voicewakeup.alwaysmicon.ApWakeupService";
    private static final String TARGET_METHOD = "isRecognitionAllowed";
    // Main Bixby app; adjust if your firmware differs.
    private static final String BIXBY_AGENT_PKG = "com.samsung.android.bixby.agent";

    private long lastLog = 0;

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) {
        if (!TARGET_PKG.equals(lpparam.packageName)) return;

        Class<?> cls = XposedHelpers.findClassIfExists(TARGET_CLASS, lpparam.classLoader);
        if (cls == null) {
            XposedBridge.log(TAG + "class not found: " + TARGET_CLASS);
            return;
        }

        try {
            XposedBridge.hookAllMethods(cls, TARGET_METHOD, new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    try {
                        Object res = param.getResult();
                        if (!(res instanceof Boolean) || (Boolean) res) return; // only act on false

                        Context ctx = (Context) param.thisObject;
                        if (!safeToOverride(ctx)) {
                            log("not overriding (call active or Bixby disabled)");
                            return;
                        }
                        param.setResult(true);
                        log("isRecognitionAllowed false -> true");
                    } catch (Throwable t) {
                        XposedBridge.log(TAG + "hook error: " + t);
                    }
                }
            });
            XposedBridge.log(TAG + "hooked " + TARGET_CLASS + "#" + TARGET_METHOD);
        } catch (Throwable t) {
            XposedBridge.log(TAG + "hook failed: " + t);
        }
    }

    private boolean safeToOverride(Context ctx) {
        // 1. No phone call / VoIP call in progress.
        AudioManager am = (AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE);
        if (am != null) {
            int mode = am.getMode();
            if (mode == AudioManager.MODE_IN_CALL
                    || mode == AudioManager.MODE_IN_COMMUNICATION
                    || mode == AudioManager.MODE_RINGTONE) {
                return false;
            }
        }
        // 2. Bixby itself must not be disabled.
        try {
            int state = ctx.getPackageManager().getApplicationEnabledSetting(BIXBY_AGENT_PKG);
            if (state == PackageManager.COMPONENT_ENABLED_STATE_DISABLED
                    || state == PackageManager.COMPONENT_ENABLED_STATE_DISABLED_USER
                    || state == PackageManager.COMPONENT_ENABLED_STATE_DISABLED_UNTIL_USED) {
                return false;
            }
        } catch (Throwable ignored) {
            return false; // package missing -> don't touch anything
        }
        return true;
    }

    private void log(String msg) { // throttle to avoid log spam
        long now = System.currentTimeMillis();
        if (now - lastLog > 5000) {
            lastLog = now;
            XposedBridge.log(TAG + msg);
        }
    }
}
